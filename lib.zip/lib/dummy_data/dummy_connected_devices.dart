import 'package:learn_bluetooth/models/bluetooth_device_model.dart';

List<BluetoothDeviceModel> dummyConnectedDevices = [
  BluetoothDeviceModel(id: '1', name: "Dummy Earphone"),
  BluetoothDeviceModel(id: '2', name: "Dummy Light"),
  BluetoothDeviceModel(id: '3', name: "Dummy AC"),
  BluetoothDeviceModel(id: '4', name: "Dummy Printer"),
  BluetoothDeviceModel(id: '5', name: "Dummy Keyboard"),
];
