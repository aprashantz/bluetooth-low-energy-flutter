class FailureModel {
  String msg;

  FailureModel({required this.msg});
}
