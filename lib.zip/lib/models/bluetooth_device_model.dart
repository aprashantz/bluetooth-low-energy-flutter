class BluetoothDeviceModel {
  String id;
  String? name;
  BluetoothDeviceModel({required this.id, this.name});
}
