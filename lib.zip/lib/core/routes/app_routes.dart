class AppRoutes {
  static const String dashboardScreen = "/dashboard-screen";
  static const String scanDevicesScreen = "/scan-devices-screen";
  static const String connectedDeviceScreen = "/connected-device-screen";
  static const String viewServicesScreen = '/view-services-screen';
}
