import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:learn_bluetooth/core/extensions/bluetoothcharacteristic_extension.dart';

class CharDetailWidget extends StatefulWidget {
  final BluetoothCharacteristic char;
  const CharDetailWidget({super.key, required this.char});

  @override
  State<CharDetailWidget> createState() => _CharDetailWidgetState();
}

class _CharDetailWidgetState extends State<CharDetailWidget> {
  ValueNotifier<List<int>> readCharValue = ValueNotifier([]);

  @override
  void initState() {
    readChar();
    super.initState();
  }

  void readChar() async {
    // readCharValue.value = await widget.char.read();
    if (widget.char.properties.read) {
      try {
        readCharValue.value = await widget.char.read();
      } catch (e) {
        debugPrint("debugReadChar: ${e.toString()}");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Name: ${widget.char.getName()}'),
        Text('Identifier: ${widget.char.getIdentifier()}'),
        Text('CharId: ${widget.char.uuid}'),
        Text("canWrite: ${widget.char.properties.write}"),
        if (widget.char.properties.read)
          ValueListenableBuilder(
            valueListenable: readCharValue,
            builder: (context, updatedChar, child) {
              String manuName = String.fromCharCodes(updatedChar);
              return manuName.isNotEmpty
                  ? Text('CharRead: $updatedChar\n ManuName: $manuName')
                  : const SizedBox();
            },
          ),
        if (widget.char.properties.write)
          ElevatedButton(
              onPressed: () async {
                Map<String, dynamic> jsonData = {
                  "OrganizationID": "dsfsdf",
                  "nodes": [
                    {
                      "nodeID": "70a2a054181e9f0a21514169",
                      "lat": "71.7887879",
                      "long": "71.7887879"
                    },
                    {"nodeID": "10", "lat": "10.1247589", "long": "40.7887879"}
                  ]
                };
                String msg = jsonEncode(jsonData);
                widget.char.write(msg.codeUnits, allowLongWrite: true);
                debugPrint("debugBluetoothNotification: writeDone");
              },
              child: const Text("Write"))
      ],
    );
  }
}
